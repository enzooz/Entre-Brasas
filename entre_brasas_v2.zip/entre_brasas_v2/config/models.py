"""
Modelo de la app Config.
Guarda la configuracion general del sistema.
"""
from django.db import models


class SystemConfig(models.Model):
    """
    Configuracion del sistema - patron SINGLETON.
    Solo puede existir UN registro en la tabla (pk=1).
    Guarda: tarifa por km, distancia minima, costo minimo de envio,
    y costo de mano de obra por hora.
    """

    # Tarifa por kilometro de envio (en pesos)
    tarifa_km = models.PositiveIntegerField(default=500)

    # Distancia minima para cobrar envio (en km)
    distancia_minima = models.DecimalField(max_digits=5, decimal_places=2, default=1)

    # Costo minimo de envio (si el calculo da menos, se cobra esto)
    costo_minimo_envio = models.PositiveIntegerField(default=1000)

    # Costo de mano de obra por hora (para reportes futuros)
    costo_hora_mano_obra = models.PositiveIntegerField(default=2500)

    class Meta:
        verbose_name = "Configuracion del Sistema"
        verbose_name_plural = "Configuraciones del Sistema"

    def save(self, *args, **kwargs):
        """
        Fuerza que siempre sea el registro pk=1.
        Asi nunca se crea un segundo registro de configuracion.
        """
        self.pk = 1
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        """No permite borrar la configuracion."""
        pass

    @classmethod
    def get_config(cls):
        """
        Devuelve la unica instancia de configuracion.
        Si no existe, la crea con los valores por defecto.
        """
        obj, created = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return "Configuracion del Sistema"
