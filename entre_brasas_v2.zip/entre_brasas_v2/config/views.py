"""
Vista de la app Config.
Solo hay una vista: el panel de configuracion.
"""
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import SystemConfig
from .forms import SystemConfigForm


def panel_config(request):
    """
    Panel de administracion para ver y editar la configuracion.
    Muestra el formulario con los valores actuales.
    """
    # Obtener la configuracion actual (si no existe, la crea)
    config = SystemConfig.get_config()

    if request.method == 'POST':
        # instance=config: editar la configuracion existente
        form = SystemConfigForm(request.POST, instance=config)
        if form.is_valid():
            form.save()
            messages.success(request, 'Configuracion guardada exitosamente')
            return redirect('config:panel_config')
    else:
        form = SystemConfigForm(instance=config)

    return render(request, 'config/panel_config.html', {'form': form})
