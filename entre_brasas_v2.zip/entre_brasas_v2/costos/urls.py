"""
URLs de la app Costos.
"""
from django.urls import path
from . import views

app_name = 'costos'

urlpatterns = [
    path('', views.ver_costos, name='ver_costos'),
]
