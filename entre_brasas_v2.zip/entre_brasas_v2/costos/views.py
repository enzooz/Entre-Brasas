"""
Vista de la app Costos.
Por ahora es un placeholder (stub).
"""
from django.shortcuts import render


def ver_costos(request):
    """Vista placeholder para costos y rentabilidad."""
    return render(request, 'costos/ver_costos.html')
