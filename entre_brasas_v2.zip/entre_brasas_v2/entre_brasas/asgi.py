"""
ASGI config para el proyecto Entre Brasas.
Se usa para servidores ASGI modernos.
"""
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'entre_brasas.settings')
application = get_asgi_application()
