"""
Configuracion principal del proyecto Entre Brasas.
Aqui se define donde esta la base de datos, que apps hay instaladas,
el idioma, la zona horaria, etc.
"""
import os
from pathlib import Path

# Carpeta donde esta este archivo
BASE_DIR = Path(__file__).resolve().parent.parent

# Clave secreta (solo para desarrollo, NUNCA subir a produccion)
SECRET_KEY = 'django-insecure-clave-desarrollo-entre-brasas-2024'

# Modo debug: muestra errores detallados en pantalla
DEBUG = True

# Hosts permitidos (vacio = solo localhost)
ALLOWED_HOSTS = []

# ============================================================
# APPS INSTALADAS
# Las que creamos nosotros van al final de la lista
# ============================================================
INSTALLED_APPS = [
    # Apps de Django (no tocar)
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # Nuestras apps
    'menu',
    'inventario',
    'pedidos',
    'config',
    'reportes',
    'costos',
]

# ============================================================
# MIDDLEWARE
# Son capas que procesan cada peticion HTTP antes de llegar a la vista
# ============================================================
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# Archivo de URLs raiz
ROOT_URLCONF = 'entre_brasas.urls'

# ============================================================
# TEMPLATES
# Donde busca Django los archivos HTML
# ============================================================
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],  # Carpeta templates/ del proyecto
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# Aplicacion WSGI (para servidores web como Gunicorn)
WSGI_APPLICATION = 'entre_brasas.wsgi.application'

# ============================================================
# BASE DE DATOS
# SQLite para desarrollo (archivo simple, sin instalar nada)
# ============================================================
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# ============================================================
# VALIDACIONES DE PASSWORD (las que vienen por defecto)
# ============================================================
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ============================================================
# IDIOMA Y ZONA HORARIA
# ============================================================
LANGUAGE_CODE = 'es-ar'  # Espanol Argentina
TIME_ZONE = 'America/Argentina/Buenos_Aires'
USE_I18N = True
USE_TZ = True

# ============================================================
# ARCHIVOS ESTATTICOS (CSS, imagenes, etc.)
# ============================================================
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

# Campo auto increment por defecto
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
