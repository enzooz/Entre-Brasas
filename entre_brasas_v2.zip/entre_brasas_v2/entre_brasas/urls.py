"""
URLs raiz del proyecto.
Aqui se conectan las URLs de cada app.
"""
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    # La pagina principal redirige a crear pedido
    path('', lambda r: redirect('pedidos:crear_pedido')),

    # URLs de cada app
    path('pedidos/', include('pedidos.urls')),
    path('menu/', include('menu.urls')),
    path('inventario/', include('inventario.urls')),
    path('config/', include('config.urls')),
    path('reportes/', include('reportes.urls')),
    path('costos/', include('costos.urls')),
]
