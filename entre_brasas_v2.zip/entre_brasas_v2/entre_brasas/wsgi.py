"""
WSGI config para el proyecto Entre Brasas.
Se usa para desplegar en servidores web como Gunicorn.
"""
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'entre_brasas.settings')
application = get_wsgi_application()
