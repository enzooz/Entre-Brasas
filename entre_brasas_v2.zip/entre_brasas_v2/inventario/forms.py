"""
Formularios de la app Inventario.
"""
from django import forms
from .models import Ingredient, InventoryMovement, Recipe


class IngredientForm(forms.ModelForm):
    """Formulario para crear o editar ingredientes."""

    class Meta:
        model = Ingredient
        fields = ['nombre', 'stock_actual', 'unidad', 'stock_minimo']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'stock_actual': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
            'unidad': forms.Select(attrs={'class': 'form-control'}),
            'stock_minimo': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
        }


class MovementForm(forms.ModelForm):
    """Formulario para registrar entradas o salidas de stock."""

    class Meta:
        model = InventoryMovement
        fields = ['ingrediente', 'tipo', 'cantidad', 'precio_unitario', 'motivo']
        widgets = {
            'ingrediente': forms.Select(attrs={'class': 'form-control'}),
            'tipo': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0.01',
                'step': '0.01'
            }),
            'precio_unitario': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'motivo': forms.TextInput(attrs={'class': 'form-control'}),
        }


class RecipeForm(forms.ModelForm):
    """Formulario para agregar un ingrediente a una receta."""

    class Meta:
        model = Recipe
        fields = ['ingrediente', 'cantidad_requerida']
        widgets = {
            'ingrediente': forms.Select(attrs={'class': 'form-control'}),
            'cantidad_requerida': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0.01',
                'step': '0.01'
            }),
        }
