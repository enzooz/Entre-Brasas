"""
Modelos de la app Inventario.
Aqui se definen los ingredientes, las recetas y los movimientos de stock.
"""
from django.db import models


# ============================================================
# MODELO: INGREDIENTE
# Cada ingrediente del inventario (carne, pan, lechuga, etc.)
# ============================================================
class Ingredient(models.Model):
    # Opciones de unidad de medida
    UNIDADES = [
        ('kg', 'Kilogramos'),
        ('g', 'Gramos'),
        ('L', 'Litros'),
        ('mL', 'Mililitros'),
        ('unidades', 'Unidades'),
    ]

    # Nombre unico del ingrediente
    nombre = models.CharField(max_length=100, unique=True)

    # Stock actual: puede tener decimales (ej: 2.5 kg)
    stock_actual = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    # Unidad de medida
    unidad = models.CharField(max_length=10, choices=UNIDADES)

    # Stock minimo: si el stock baja de esto, se alerta
    stock_minimo = models.DecimalField(max_digits=10, decimal_places=2)

    # Precio de la ultima compra en pesos
    precio_compra = models.PositiveIntegerField(default=0)

    # Si esta activo en el sistema
    activo = models.BooleanField(default=True)

    class Meta:
        ordering = ['nombre']
        verbose_name = "Ingrediente"
        verbose_name_plural = "Ingredientes"

    @property
    def stock_bajo(self):
        """
        Propiedad calculada: devuelve True si el stock actual
        es menor al stock minimo. Se usa como:
        ingrediente.stock_bajo (sin parentesis)
        """
        return self.stock_actual < self.stock_minimo

    def __str__(self):
        return self.nombre


# ============================================================
# MODELO: RECETA
# Vincula un producto (hamburguesa o adicional) con sus ingredientes.
# Ejemplo: "Clasica" necesita 0.200 kg de Carne molida, 1 Pan, etc.
#
# Usa un "polimorfismo simple": en vez de tener dos foreign keys
# (una para hamburguesa y otra para adicional), usa:
#   - producto_tipo: 'hamburger' o 'addon'
#   - producto_id: el ID del producto
# ============================================================
class Recipe(models.Model):
    TIPOS_PRODUCTO = [
        ('hamburger', 'Hamburguesa'),
        ('addon', 'Adicional'),
    ]

    # Tipo de producto (hamburguesa o adicional)
    producto_tipo = models.CharField(max_length=10, choices=TIPOS_PRODUCTO)

    # ID del producto (puede ser un Hamburger o un Addon)
    producto_id = models.PositiveIntegerField()

    # Ingrediente que se necesita
    ingrediente = models.ForeignKey(
        Ingredient,
        on_delete=models.CASCADE,  # Si se borra el ingrediente, se borra la receta
        related_name='recetas'
    )

    # Cuanto ingrediente se necesita (ej: 0.200 kg de carne)
    cantidad_requerida = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        # No puede haber dos recetas iguales para el mismo producto e ingrediente
        unique_together = ['producto_tipo', 'producto_id', 'ingrediente']
        ordering = ['producto_tipo', 'producto_id']
        verbose_name = "Receta"
        verbose_name_plural = "Recetas"

    def __str__(self):
        return f"#{self.producto_id} - {self.ingrediente.nombre}"


# ============================================================
# MODELO: MOVIMIENTO DE INVENTARIO
# Registra cada entrada o salida de stock.
# Ejemplo: "Entrada de 5 kg de Carne molida - Compra al proveedor"
# ============================================================
class InventoryMovement(models.Model):
    TIPOS = [
        ('entrada', 'Entrada'),
        ('salida', 'Salida'),
    ]

    # Que ingrediente se mueve
    ingrediente = models.ForeignKey(
        Ingredient,
        on_delete=models.CASCADE,
        related_name='movimientos'
    )

    # Tipo de movimiento: entrada o salida
    tipo = models.CharField(max_length=10, choices=TIPOS)

    # Cantidad que se mueve
    cantidad = models.DecimalField(max_digits=10, decimal_places=2)

    # Motivo del movimiento (obligatorio para trazabilidad)
    motivo = models.CharField(max_length=255)

    # Precio unitario al que se compro (para entradas)
    precio_unitario = models.PositiveIntegerField(default=0)

    # Fecha automatica al crear el registro
    fecha = models.DateTimeField(auto_now_add=True)

    # Pedido relacionado (si el movimiento fue por un pedido)
    # null=True y blank=True significan que puede no tener pedido asociado
    pedido_relacionado = models.ForeignKey(
        'pedidos.Order',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,  # Si se borra el pedido, el movimiento queda
        related_name='movimientos_inventario'
    )

    class Meta:
        ordering = ['-fecha']  # Los mas recientes primero
        verbose_name = "Movimiento de Inventario"
        verbose_name_plural = "Movimientos de Inventario"

    def __str__(self):
        tipo_display = 'Entrada' if self.tipo == 'entrada' else 'Salida'
        return f"{tipo_display} - {self.ingrediente.nombre} ({self.cantidad})"
