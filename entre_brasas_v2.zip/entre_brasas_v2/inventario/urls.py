"""
URLs de la app Inventario.
"""
from django.urls import path
from . import views

app_name = 'inventario'

urlpatterns = [
    path('', views.ver_inventario, name='ver_inventario'),
    path('movimiento/', views.registrar_movimiento, name='registrar_movimiento'),
    path('ingredientes/', views.listar_ingredientes, name='listar_ingredientes'),
    path('ingredientes/crear/', views.crear_ingrediente, name='crear_ingrediente'),
    path('ingredientes/<int:pk>/editar/', views.editar_ingrediente, name='editar_ingrediente'),
    path('ingredientes/<int:pk>/toggle/', views.toggle_ingrediente, name='toggle_ingrediente'),
    path('recetas/', views.ver_recetas, name='ver_recetas'),
    path('recetas/agregar/', views.agregar_receta_item, name='agregar_receta_item'),
    path('recetas/<int:pk>/eliminar/', views.eliminar_receta_item, name='eliminar_receta_item'),
]
