"""
Vistas de la app Inventario.
Toda la logica de stock, movimientos y recetas va aqui.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db import models
from .models import Ingredient, InventoryMovement, Recipe
from .forms import IngredientForm, MovementForm, RecipeForm
from menu.models import Hamburger, Addon


# ============================================================
# VISTAS DE INGREDIENTES
# ============================================================

def ver_inventario(request):
    """
    Muestra el estado actual del inventario.
    Resalta los ingredientes con stock bajo.
    """
    ingredientes = Ingredient.objects.filter(activo=True)
    # Filtrar los que tienen stock bajo usando F() para comparar campos
    stock_bajo = ingredientes.filter(stock_actual__lt=models.F('stock_minimo'))

    return render(request, 'inventario/ver_inventario.html', {
        'ingredientes': ingredientes,
        'stock_bajo': stock_bajo,
    })


def listar_ingredientes(request):
    """Lista todos los ingredientes (activos e inactivos)."""
    ingredientes = Ingredient.objects.all()
    return render(request, 'inventario/listar_ingredientes.html', {
        'ingredientes': ingredientes,
    })


def crear_ingrediente(request):
    """Formulario para crear un ingrediente nuevo."""
    if request.method == 'POST':
        form = IngredientForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Ingrediente creado exitosamente')
            return redirect('inventario:listar_ingredientes')
    else:
        form = IngredientForm()

    return render(request, 'inventario/formulario_ingrediente.html', {
        'form': form,
        'modo': 'crear',
    })


def editar_ingrediente(request, pk):
    """Formulario para editar un ingrediente existente."""
    ingrediente = get_object_or_404(Ingredient, pk=pk)

    if request.method == 'POST':
        form = IngredientForm(request.POST, instance=ingrediente)
        if form.is_valid():
            form.save()
            messages.success(request, 'Ingrediente actualizado exitosamente')
            return redirect('inventario:listar_ingredientes')
    else:
        form = IngredientForm(instance=ingrediente)

    return render(request, 'inventario/formulario_ingrediente.html', {
        'form': form,
        'modo': 'editar',
    })


def toggle_ingrediente(request, pk):
    """Activa o desactiva un ingrediente."""
    ingrediente = get_object_or_404(Ingredient, pk=pk)
    ingrediente.activo = not ingrediente.activo
    ingrediente.save()

    estado = 'activado' if ingrediente.activo else 'desactivado'
    messages.success(request, f'Ingrediente {estado} exitosamente')
    return redirect('inventario:listar_ingredientes')


# ============================================================
# MOVIMIENTOS DE INVENTARIO
# ============================================================

def registrar_movimiento(request):
    """
    Formulario para registrar entrada o salida de stock.
    AQUI SE ACTUALIZA EL STOCK:
    - Si es ENTRADA: suma la cantidad al stock
    - Si es SALIDA: resta la cantidad del stock
    """
    if request.method == 'POST':
        form = MovementForm(request.POST)
        if form.is_valid():
            # commit=False crea el objeto en memoria sin guardarlo en la BD
            # Asi podemos modificarlo antes de guardar
            movimiento = form.save(commit=False)
            ingrediente = movimiento.ingrediente

            # Validar que no se saque mas de lo que hay
            if movimiento.tipo == 'salida':
                if movimiento.cantidad > ingrediente.stock_actual:
                    messages.error(
                        request,
                        f'Stock insuficiente. Stock actual: '
                        f'{ingrediente.stock_actual} {ingrediente.unidad}'
                    )
                    return redirect('inventario:ver_inventario')

            # Actualizar el stock del ingrediente
            if movimiento.tipo == 'entrada':
                ingrediente.stock_actual += movimiento.cantidad
                # Si se indico precio de compra, actualizarlo
                if movimiento.precio_unitario > 0:
                    ingrediente.precio_compra = movimiento.precio_unitario
            else:  # salida
                ingrediente.stock_actual -= movimiento.cantidad

            # Guardar los cambios
            ingrediente.save()
            movimiento.save()

            tipo = 'Entrada' if movimiento.tipo == 'entrada' else 'Salida'
            messages.success(
                request,
                f'{tipo} registrada: {movimiento.cantidad} '
                f'{ingrediente.unidad} de {ingrediente.nombre}'
            )
            return redirect('inventario:ver_inventario')
    else:
        form = MovementForm()

    return render(request, 'inventario/formulario_movimiento.html', {'form': form})


# ============================================================
# RECETAS
# ============================================================

def ver_recetas(request):
    """
    Pagina para ver y gestionar recetas.
    Seleccionas tipo (hamburguesa/addon) y producto, y ves sus ingredientes.
    """
    hamburguesas = Hamburger.objects.filter(activa=True)
    adicionales = Addon.objects.filter(activo=True)
    ingredientes = Ingredient.objects.filter(activo=True)

    # Obtener filtros del formulario GET (la URL)
    tipo = request.GET.get('tipo', '')
    producto_id = request.GET.get('producto', '')
    receta_items = []

    if tipo and producto_id:
        receta_items = Recipe.objects.filter(
            producto_tipo=tipo,
            producto_id=producto_id,
        ).select_related('ingrediente')  # Optimiza la consulta SQL

    return render(request, 'inventario/ver_recetas.html', {
        'hamburguesas': hamburguesas,
        'adicionales': adicionales,
        'ingredientes': ingredientes,
        'receta_items': receta_items,
        'tipo_seleccionado': tipo,
        'producto_seleccionado': producto_id,
    })


def agregar_receta_item(request):
    """
    Agrega un ingrediente a la receta de un producto.
    Se llama desde el form de ver_recetas.
    """
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            receta = form.save(commit=False)
            # Obtener tipo y producto del form (son campos ocultos)
            receta.producto_tipo = request.POST.get('producto_tipo')
            receta.producto_id = request.POST.get('producto_id')
            receta.save()
            messages.success(request, 'Ingrediente agregado a la receta')
            # Redirigir de vuelta a la receta del producto
            url = (
                f'/inventario/recetas/?tipo={receta.producto_tipo}'
                f'&producto={receta.producto_id}'
            )
            return redirect(url)

    return redirect('inventario:ver_recetas')


def eliminar_receta_item(request, pk):
    """Elimina un ingrediente de una receta."""
    receta = get_object_or_404(Recipe, pk=pk)
    tipo = receta.producto_tipo
    producto_id = receta.producto_id
    receta.delete()
    messages.success(request, 'Ingrediente eliminado de la receta')
    url = f'/inventario/recetas/?tipo={tipo}&producto={producto_id}'
    return redirect(url)
