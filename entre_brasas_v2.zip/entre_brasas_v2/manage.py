#!/usr/bin/env python
"""
Script de Django para tareas administrativas.
Se usa para correr el servidor, crear migraciones, etc.
"""
import os
import sys


def main():
    """Ejecuta las tareas administrativas de Django."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'entre_brasas.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "No se pudo importar Django. Esta instalado? "
            "Activa el entorno virtual primero."
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
