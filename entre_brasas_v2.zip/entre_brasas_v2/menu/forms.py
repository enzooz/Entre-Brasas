"""
Formularios de la app Menu.
Django genera automaticamente el HTML del formulario
a partir de los modelos, y nosotros le damos estilo.
"""
from django import forms
from .models import Hamburger, Addon


class HamburgerForm(forms.ModelForm):
    """
    Formulario para crear o editar hamburguesas.
    Genera automaticamente los campos a partir del modelo.
    """

    class Meta:
        model = Hamburger
        # Campos que se muestran en el formulario
        fields = ['nombre', 'descripcion', 'precio', 'incluye_papas']
        # Widgets: como se renderiza cada campo en HTML
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'precio': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
            'incluye_papas': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class AddonForm(forms.ModelForm):
    """
    Formulario para crear o editar adicionales.
    """

    class Meta:
        model = Addon
        fields = ['nombre', 'precio', 'hamburguesas']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'precio': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
            # CheckboxSelectMultiple: muestra checkboxes para elegir varias hamburguesas
            'hamburguesas': forms.CheckboxSelectMultiple(),
        }

    def clean(self):
        """
        Validacion extra: debe haber al menos una hamburguesa seleccionada.
        Este metodo se ejecuta automaticamente al validar el form.
        """
        cleaned_data = super().clean()
        hamburguesas = cleaned_data.get('hamburguesas')
        if not hamburguesas:
            raise forms.ValidationError('Debe asociar al menos una hamburguesa')
        return cleaned_data
