"""
Modelos de la app Menu.
Aqui se definen las hamburguesas y los adicionales del negocio.
"""
from django.db import models


# ============================================================
# MODELO: HAMBURGUESA
# Representa cada hamburguesa que se puede vender.
# ============================================================
class Hamburger(models.Model):
    # Nombre unico (no se puede repetir)
    nombre = models.CharField(max_length=100, unique=True)

    # Descripcion corta de los ingredientes
    descripcion = models.TextField()

    # Precio base en pesos argentinos (entero positivo)
    precio = models.PositiveIntegerField()

    # Si incluye papas fritas o no
    incluye_papas = models.BooleanField(default=True)

    # Si esta activa (disponible para vender) o no
    activa = models.BooleanField(default=True)

    class Meta:
        # Ordenar por nombre de forma alfabetica
        ordering = ['nombre']
        # Nombres bonitos para el admin de Django
        verbose_name = "Hamburguesa"
        verbose_name_plural = "Hamburguesas"

    def __str__(self):
        """Lo que se muestra al imprimir el objeto (ej: en el admin)."""
        return self.nombre


# ============================================================
# MODELO: ADICIONAL
# Extras que se le pueden agregar a una hamburguesa
# (ej: Bacon Extra, Guacamole, Doble Carne)
# ============================================================
class Addon(models.Model):
    # Nombre unico
    nombre = models.CharField(max_length=100, unique=True)

    # Precio del adicional
    precio = models.PositiveIntegerField()

    # RELACION MANY-TO-MANY: un adicional puede estar disponible
    # en varias hamburguesas, y una hamburguesa puede tener varios adicionales.
    # Ejemplo: "Bacon Extra" esta disponible en Clasica, Especial, Doble Bacon, BBQ
    hamburguesas = models.ManyToManyField(
        Hamburger,
        related_name='adicionales',  # Permite hacer: hamburguesa.adicionales.all()
        blank=True
    )

    # Si esta activo o no
    activo = models.BooleanField(default=True)

    class Meta:
        ordering = ['nombre']
        verbose_name = "Adicional"
        verbose_name_plural = "Adicionales"

    def __str__(self):
        return self.nombre
