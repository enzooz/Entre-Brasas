"""
URLs de la app Menu.
Conecta cada URL con su vista correspondiente.
"""
from django.urls import path
from . import views

# Namespace: permite usar menu:listar_hamburguesas en vez de solo listar_hamburguesas
app_name = 'menu'

urlpatterns = [
    # Hamburguesas
    path('hamburguesas/', views.listar_hamburguesas, name='listar_hamburguesas'),
    path('hamburguesas/crear/', views.crear_hamburguesa, name='crear_hamburguesa'),
    path('hamburguesas/<int:pk>/editar/', views.editar_hamburguesa, name='editar_hamburguesa'),
    path('hamburguesas/<int:pk>/toggle/', views.toggle_hamburguesa, name='toggle_hamburguesa'),
    # Adicionales
    path('adicionales/', views.listar_adicionales, name='listar_adicionales'),
    path('adicionales/crear/', views.crear_adicional, name='crear_adicional'),
    path('adicionales/<int:pk>/editar/', views.editar_adicional, name='editar_adicional'),
    path('adicionales/<int:pk>/toggle/', views.toggle_adicional, name='toggle_adicional'),
]
