"""
Vistas de la app Menu.
Cada vista es una funcion que recibe un request y devuelve un response.
Aqui va TODA la logica (no hay services.py).
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Hamburger, Addon
from .forms import HamburgerForm, AddonForm


# ============================================================
# VISTAS DE HAMBURGUESAS
# ============================================================

def listar_hamburguesas(request):
    """Lista todas las hamburguesas del menu."""
    hamburguesas = Hamburger.objects.all()
    return render(request, 'menu/listar_hamburguesas.html', {
        'hamburguesas': hamburguesas,
    })


def crear_hamburguesa(request):
    """
    Muestra formulario para crear una hamburguesa nueva.
    GET: muestra el form vacio.
    POST: procesa los datos y guarda en la BD.
    """
    if request.method == 'POST':
        # Crear form con los datos del formulario
        form = HamburgerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Hamburguesa creada exitosamente')
            return redirect('menu:listar_hamburguesas')
    else:
        # GET: form vacio
        form = HamburgerForm()

    return render(request, 'menu/formulario_hamburguesa.html', {
        'form': form,
        'modo': 'crear',
    })


def editar_hamburguesa(request, pk):
    """
    Muestra formulario para editar una hamburguesa existente.
    instance=hamburguesa le dice al form que cargue los datos actuales.
    """
    hamburguesa = get_object_or_404(Hamburger, pk=pk)

    if request.method == 'POST':
        # instance=hamburguesa: editar esta hamburguesa en vez de crear una nueva
        form = HamburgerForm(request.POST, instance=hamburguesa)
        if form.is_valid():
            form.save()
            messages.success(request, 'Hamburguesa actualizada exitosamente')
            return redirect('menu:listar_hamburguesas')
    else:
        form = HamburgerForm(instance=hamburguesa)

    return render(request, 'menu/formulario_hamburguesa.html', {
        'form': form,
        'modo': 'editar',
    })


def toggle_hamburguesa(request, pk):
    """
    Activa o desactiva una hamburguesa.
    Si esta activa la desactiva, y viceversa.
    """
    hamburguesa = get_object_or_404(Hamburger, pk=pk)
    hamburguesa.activa = not hamburguesa.activa
    hamburguesa.save()

    estado = 'activada' if hamburguesa.activa else 'desactivada'
    messages.success(request, f'Hamburguesa {estado} exitosamente')
    return redirect('menu:listar_hamburguesas')


# ============================================================
# VISTAS DE ADICIONALES
# ============================================================

def listar_adicionales(request):
    """Lista todos los adicionales del menu."""
    adicionales = Addon.objects.all()
    return render(request, 'menu/listar_adicionales.html', {
        'adicionales': adicionales,
    })


def crear_adicional(request):
    """Formulario para crear un adicional nuevo."""
    if request.method == 'POST':
        form = AddonForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Adicional creado exitosamente')
            return redirect('menu:listar_adicionales')
    else:
        form = AddonForm()

    return render(request, 'menu/formulario_adicional.html', {
        'form': form,
        'modo': 'crear',
    })


def editar_adicional(request, pk):
    """Formulario para editar un adicional existente."""
    adicional = get_object_or_404(Addon, pk=pk)

    if request.method == 'POST':
        form = AddonForm(request.POST, instance=adicional)
        if form.is_valid():
            form.save()
            messages.success(request, 'Adicional actualizado exitosamente')
            return redirect('menu:listar_adicionales')
    else:
        form = AddonForm(instance=adicional)

    return render(request, 'menu/formulario_adicional.html', {
        'form': form,
        'modo': 'editar',
    })


def toggle_adicional(request, pk):
    """Activa o desactiva un adicional."""
    adicional = get_object_or_404(Addon, pk=pk)
    adicional.activo = not adicional.activo
    adicional.save()

    estado = 'activado' if adicional.activo else 'desactivado'
    messages.success(request, f'Adicional {estado} exitosamente')
    return redirect('menu:listar_adicionales')
