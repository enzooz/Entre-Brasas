"""
Modelos de la app Pedidos.
Aqui se define todo lo relacionado con los pedidos de los clientes.
"""
from django.db import models


class Order(models.Model):
    """
    Pedido realizado por un cliente.
    Guarda los datos del cliente, metodo de pago, envio, total y estado.
    """
    # Estados posibles de un pedido
    ESTADOS = [
        ('pendiente', 'Pendiente'),
        ('en_preparacion', 'En preparacion'),
        ('en_camino', 'En camino'),
        ('entregado', 'Entregado'),
        ('cancelado', 'Cancelado'),
    ]

    # Metodos de pago aceptados
    METODOS_PAGO = [
        ('efectivo', 'Efectivo'),
        ('transferencia', 'Transferencia/QR'),
    ]

    # Datos del cliente
    cliente_nombre = models.CharField(max_length=200)
    cliente_telefono = models.CharField(max_length=50)
    cliente_direccion = models.CharField(max_length=300)
    observaciones = models.TextField(blank=True, null=True)

    # Metodo de pago
    metodo_pago = models.CharField(max_length=20, choices=METODOS_PAGO)

    # Datos de envio
    distancia_km = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    costo_envio = models.PositiveIntegerField(default=0)
    retiro_local = models.BooleanField(default=False)

    # Totales y estado
    total = models.PositiveIntegerField(default=0)
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')

    # Fecha de creacion (automatica)
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['fecha_creacion']
        verbose_name = "Pedido"
        verbose_name_plural = "Pedidos"

    def __str__(self):
        return f"Pedido #{self.pk} - {self.cliente_nombre}"


class OrderItem(models.Model):
    """
    Un item dentro de un pedido.
    Cada item es una hamburguesa con su cantidad y precio.
    """
    # A que pedido pertenece (si se borra el pedido, se borran sus items)
    pedido = models.ForeignKey(
        Order,
        related_name='items',  # Permite hacer: pedido.items.all()
        on_delete=models.CASCADE
    )

    # Que hamburguesa se pidio
    hamburguesa = models.ForeignKey(
        'menu.Hamburger',
        on_delete=models.CASCADE
    )

    # Cantidad de esa hamburguesa
    cantidad = models.PositiveIntegerField(default=1)

    # Precio al momento de la venta (snapshot, no se actualiza si cambia el precio)
    precio_unitario = models.PositiveIntegerField()

    class Meta:
        verbose_name = "Item del Pedido"
        verbose_name_plural = "Items del Pedido"

    @property
    def subtotal(self):
        """Subtotal de este item: precio unitario multiplicado por cantidad."""
        return self.precio_unitario * self.cantidad

    def __str__(self):
        return f"{self.hamburguesa.nombre} x{self.cantidad}"


class OrderItemAddon(models.Model):
    """
    Adicional de un item del pedido.
    Guarda el precio al momento de la venta.
    """
    # A que item del pedido pertenece
    item = models.ForeignKey(
        OrderItem,
        related_name='adicionales',
        on_delete=models.CASCADE
    )

    # Que adicional se pidio
    adicional = models.ForeignKey(
        'menu.Addon',
        on_delete=models.CASCADE
    )

    # Precio al momento de la venta
    precio = models.PositiveIntegerField()

    class Meta:
        verbose_name = "Adicional del Item"
        verbose_name_plural = "Adicionales del Item"

    def __str__(self):
        return f"{self.adicional.nombre}"


class OrderStatusHistory(models.Model):
    """
    Historial de cambios de estado de un pedido.
    Cada vez que un pedido cambia de estado, se crea un registro aqui.
    """
    # A que pedido pertenece
    pedido = models.ForeignKey(
        Order,
        related_name='historial',
        on_delete=models.CASCADE
    )

    # Estado anterior y nuevo
    estado_anterior = models.CharField(max_length=20)
    estado_nuevo = models.CharField(max_length=20)

    # Observacion (opcional, ej: motivo de cancelacion)
    observacion = models.TextField(blank=True, null=True)

    # Fecha del cambio (automatica)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-fecha']  # Los mas recientes primero
        verbose_name = "Historial de Estado"
        verbose_name_plural = "Historial de Estados"

    def __str__(self):
        return f"Pedido #{self.pedido.pk}: {self.estado_anterior} -> {self.estado_nuevo}"
