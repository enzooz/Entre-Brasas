"""
URLs de la app Pedidos.
"""
from django.urls import path
from . import views

app_name = 'pedidos'

urlpatterns = [
    path('nuevo/', views.crear_pedido, name='crear_pedido'),
    path('cola/', views.cola_pedidos, name='cola_pedidos'),
    path('historial/', views.historial_pedidos, name='historial_pedidos'),
    path('<int:order_id>/', views.detalle_pedido, name='detalle_pedido'),
    path('<int:order_id>/avanzar/', views.avanzar_pedido, name='avanzar_pedido'),
    path('<int:order_id>/cancelar/', views.cancelar_pedido, name='cancelar_pedido'),
]
