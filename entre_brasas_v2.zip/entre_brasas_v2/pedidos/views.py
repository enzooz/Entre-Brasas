"""
Vistas de la app Pedidos.
TODA la logica de pedidos va aqui: crear, avanzar estado, cancelar,
calcular envio, calcular total, descontar stock, devolver stock.
NO hay services.py -- todo esta en este archivo.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Order, OrderItem, OrderItemAddon, OrderStatusHistory
from menu.models import Hamburger, Addon
from inventario.models import Recipe, InventoryMovement
from config.models import SystemConfig


# ============================================================
# FUNCIONES AUXILIARES
# Estas funciones ayudan a las vistas pero no son vistas en si.
# Estan AQUI en views.py (no en un services.py).
# ============================================================

def calcular_envio(distancia_km, retiro_local):
    """
    Calcula el costo de envio segun la distancia y la configuracion del sistema.

    Reglas:
    1. Si es retiro en local, el envio es $0
    2. Si la distancia es menor a la minima, el envio es $0
    3. Sino: costo = distancia * tarifa_km
    4. El costo no puede ser menor al costo minimo de envio
    """
    if retiro_local:
        return 0

    distancia = float(distancia_km or 0)
    config = SystemConfig.get_config()

    # Si la distancia es menor a la minima, no se cobra envio
    if distancia < config.distancia_minima:
        return 0

    costo = distancia * config.tarifa_km
    # El costo no puede ser menor al minimo
    return max(costo, config.costo_minimo_envio)


def calcular_total(pedido):
    """
    Calcula el total del pedido sumando:
    - (precio_unitario * cantidad) de cada hamburguesa
    - (precio_adicional * cantidad) de cada adicional
    - costo de envio
    """
    total = 0
    for item in pedido.items.all():
        # Sumar el precio de la hamburguesa
        total += item.precio_unitario * item.cantidad
        # Sumar el precio de los adicionales
        for addon in item.adicionales.all():
            total += addon.precio * item.cantidad
    # Sumar el costo de envio
    total += pedido.costo_envio
    return total


def descontar_stock(pedido):
    """
    Descuenta stock cuando un pedido pasa a "En preparacion".

    Primero VERIFICA que haya stock suficiente para TODO.
    Si falta algo, lanza un ValueError y no descuenta nada.

    DESPUES, si hay stock para todo, descuenta y crea movimientos.
    """
    # PASO 1: Verificar que hay stock para TODO
    for item in pedido.items.all():
        # Buscar la receta de esta hamburguesa
        recetas = Recipe.objects.filter(
            producto_tipo='hamburger',
            producto_id=item.hamburguesa.id
        )
        for receta in recetas:
            # Calcular cuanto ingrediente se necesita en total
            cantidad_total = receta.cantidad_requerida * item.cantidad
            # Verificar si hay stock suficiente
            if receta.ingrediente.stock_actual < cantidad_total:
                raise ValueError(
                    f'Stock insuficiente: {receta.ingrediente.nombre}. '
                    f'Requerido: {cantidad_total} {receta.ingrediente.unidad}, '
                    f'Disponible: {receta.ingrediente.stock_actual} '
                    f'{receta.ingrediente.unidad}'
                )

    # PASO 2: Si hay stock para todo, descontar
    for item in pedido.items.all():
        recetas = Recipe.objects.filter(
            producto_tipo='hamburger',
            producto_id=item.hamburguesa.id
        )
        for receta in recetas:
            cantidad_total = receta.cantidad_requerida * item.cantidad

            # Crear un movimiento de salida en el inventario
            InventoryMovement.objects.create(
                ingrediente=receta.ingrediente,
                tipo='salida',
                cantidad=cantidad_total,
                motivo=f'Descuento automatico - Pedido #{pedido.id}',
                pedido_relacionado=pedido
            )

            # Restar el stock del ingrediente
            receta.ingrediente.stock_actual -= cantidad_total
            receta.ingrediente.save()


def devolver_stock(pedido):
    """
    Devuelve el stock cuando se cancela un pedido.
    Busca los movimientos de salida que se hicieron para este pedido
    y crea movimientos de entrada inversos.
    """
    # Buscar todos los movimientos de salida de este pedido
    movimientos = InventoryMovement.objects.filter(
        pedido_relacionado=pedido,
        tipo='salida'
    )

    for mov in movimientos:
        # Crear un movimiento de entrada inverso
        InventoryMovement.objects.create(
            ingrediente=mov.ingrediente,
            tipo='entrada',
            cantidad=mov.cantidad,
            motivo=f'Devolucion por cancelacion - Pedido #{pedido.id}',
            pedido_relacionado=pedido
        )
        # Sumar el stock de vuelta
        mov.ingrediente.stock_actual += mov.cantidad
        mov.ingrediente.save()


def crear_items_pedido(pedido, post_data):
    """
    Crea los items del pedido desde los datos del formulario.
    Recibe los datos POST del request y crea OrderItem + OrderItemAddon.

    Los datos llegan asi en el POST:
    - hamburger_ids[]: lista de IDs de hamburguesas seleccionadas
    - quantities[]: lista de cantidades
    - addon_ids_hamburger_1[]: adicionales para la hamburguesa con ID 1
    """
    hamburger_ids = post_data.getlist('hamburger_ids[]')
    cantidades = post_data.getlist('quantities[]')

    for i, hamburger_id in enumerate(hamburger_ids):
        if not hamburger_id:
            continue

        # Buscar la hamburguesa
        hamburguesa = get_object_or_404(Hamburger, pk=hamburger_id)
        cantidad = int(cantidades[i]) if i < len(cantidades) else 1

        # Crear el item del pedido
        item = OrderItem.objects.create(
            pedido=pedido,
            hamburguesa=hamburguesa,
            cantidad=cantidad,
            precio_unitario=hamburguesa.precio
        )

        # Buscar los adicionales seleccionados para esta hamburguesa
        addon_key = f'addon_ids_hamburger_{hamburger_id}[]'
        addon_nombres = post_data.getlist(addon_key)
        for addon_nombre in addon_nombres:
            if addon_nombre:
                addon = Addon.objects.filter(nombre=addon_nombre).first()
                if addon:
                    OrderItemAddon.objects.create(
                        item=item,
                        adicional=addon,
                        precio=addon.precio
                    )


# ============================================================
# VISTAS DE PEDIDOS
# ============================================================

def crear_pedido(request):
    """
    Vista principal para crear un pedido nuevo.

    GET: muestra el formulario con hamburguesas, adicionales y configuracion.
    POST: procesa el formulario, crea el pedido, items y calcula el total.
    """
    if request.method == 'POST':
        # 1. Obtener datos del formulario
        retiro_local = request.POST.get('retiro_local') == 'on'

        # 2. Crear el pedido basico
        pedido = Order.objects.create(
            cliente_nombre=request.POST['cliente_nombre'],
            cliente_telefono=request.POST['cliente_telefono'],
            cliente_direccion=request.POST['cliente_direccion'],
            observaciones=request.POST.get('observaciones', ''),
            metodo_pago=request.POST['metodo_pago'],
            distancia_km=request.POST.get('distancia_km', 0) or 0,
            retiro_local=retiro_local,
            costo_envio=calcular_envio(
                request.POST.get('distancia_km', 0),
                retiro_local
            ),
        )

        # 3. Crear los items del pedido (hamburguesas + adicionales)
        crear_items_pedido(pedido, request.POST)

        # 4. Calcular y guardar el total
        pedido.total = calcular_total(pedido)
        pedido.save()

        messages.success(request, f'Pedido #{pedido.pk} creado exitosamente')
        return redirect('pedidos:cola_pedidos')
    else:
        # GET: cargar datos para el formulario
        hamburguesas = Hamburger.objects.filter(activa=True)
        adicionales = Addon.objects.filter(activo=True)
        config = SystemConfig.get_config()

    return render(request, 'pedidos/crear_pedido.html', {
        'hamburguesas': hamburguesas,
        'adicionales': adicionales,
        'config': config,
    })


def cola_pedidos(request):
    """
    Muestra los pedidos activos (no entregados ni cancelados).
    Permite filtrar por nombre de cliente y por estado.
    """
    pedidos = Order.objects.exclude(estado__in=['entregado', 'cancelado'])

    # Filtros de busqueda
    busqueda = request.GET.get('search', '')
    filtro_estado = request.GET.get('estado', '')

    if busqueda:
        # Filtrar por nombre (icontains = no importa mayusculas/minusculas)
        pedidos = pedidos.filter(cliente_nombre__icontains=busqueda)
    if filtro_estado:
        pedidos = pedidos.filter(estado=filtro_estado)

    return render(request, 'pedidos/cola_pedidos.html', {
        'pedidos': pedidos,
        'busqueda': busqueda,
        'filtro_estado': filtro_estado,
    })


def detalle_pedido(request, order_id):
    """Muestra el detalle completo de un pedido."""
    pedido = get_object_or_404(Order, pk=order_id)

    # Calcular subtotales para mostrar en el template
    total_productos = sum(item.subtotal for item in pedido.items.all())
    total_adicionales = sum(
        addon.precio * item.cantidad
        for item in pedido.items.all()
        for addon in item.adicionales.all()
    )

    return render(request, 'pedidos/detalle_pedido.html', {
        'pedido': pedido,
        'total_productos': total_productos,
        'total_adicionales': total_adicionales,
    })


def avanzar_pedido(request, order_id):
    """
    Avanza el estado del pedido al siguiente.

    Flujo de estados:
    pendiente -> en_preparacion -> en_camino -> entregado

    Cuando pasa a 'en_preparacion', descuenta stock automaticamente.
    """
    pedido = get_object_or_404(Order, pk=order_id)

    # Definir cual es el estado siguiente
    ESTADOS_SIGUIENTES = {
        'pendiente': 'en_preparacion',
        'en_preparacion': 'en_camino',
        'en_camino': 'entregado',
    }

    nuevo_estado = ESTADOS_SIGUIENTES.get(pedido.estado)

    # Si no hay estado siguiente (ya esta entregado o cancelado)
    if not nuevo_estado:
        messages.error(request, 'No se puede avanzar este pedido')
        return redirect('pedidos:cola_pedidos')

    # Si pasa a "en preparacion", descontar stock
    if nuevo_estado == 'en_preparacion':
        try:
            descontar_stock(pedido)
        except ValueError as e:
            # Si no hay stock suficiente, mostrar error
            messages.error(request, str(e))
            return redirect('pedidos:cola_pedidos')

    # Registrar el cambio en el historial
    OrderStatusHistory.objects.create(
        pedido=pedido,
        estado_anterior=pedido.estado,
        estado_nuevo=nuevo_estado,
    )

    # Actualizar el estado del pedido
    pedido.estado = nuevo_estado
    pedido.save()

    messages.success(
        request,
        f'Pedido #{pedido.pk} avanzado a {pedido.get_estado_display()}'
    )
    return redirect('pedidos:cola_pedidos')


def cancelar_pedido(request, order_id):
    """
    Cancela un pedido.

    Si el pedido ya paso por "en preparacion" o "en camino",
    pregunta si se debe devolver el stock.
    """
    pedido = get_object_or_404(Order, pk=order_id)

    # Si el pedido ya tuvo descuento de stock, preguntar si devolver
    if pedido.estado in ['en_preparacion', 'en_camino']:
        devolver = request.POST.get('devolver_stock') == 'on'
        if devolver:
            devolver_stock(pedido)
            messages.success(request, f'Stock devuelto para el Pedido #{pedido.pk}')
        else:
            messages.warning(
                request,
                f'Stock NO devuelto - Pedido #{pedido.pk} registrado como perdida'
            )

    # Registrar en historial
    OrderStatusHistory.objects.create(
        pedido=pedido,
        estado_anterior=pedido.estado,
        estado_nuevo='cancelado',
        observacion=request.POST.get('motivo_cancelacion', ''),
    )

    # Cambiar estado a cancelado
    pedido.estado = 'cancelado'
    pedido.save()

    messages.success(request, f'Pedido #{pedido.pk} cancelado')
    return redirect('pedidos:cola_pedidos')


def historial_pedidos(request):
    """
    Muestra pedidos finalizados (entregados o cancelados).
    Permite filtrar por nombre, estado y rango de fechas.
    """
    pedidos = Order.objects.filter(estado__in=['entregado', 'cancelado'])

    # Filtros
    busqueda = request.GET.get('search', '')
    filtro_estado = request.GET.get('estado', '')
    fecha_desde = request.GET.get('fecha_desde', '')
    fecha_hasta = request.GET.get('fecha_hasta', '')

    if busqueda:
        pedidos = pedidos.filter(cliente_nombre__icontains=busqueda)
    if filtro_estado:
        pedidos = pedidos.filter(estado=filtro_estado)
    if fecha_desde:
        # Filtrar por fecha mayor o igual
        pedidos = pedidos.filter(fecha_creacion__date__gte=fecha_desde)
    if fecha_hasta:
        # Filtrar por fecha menor o igual
        pedidos = pedidos.filter(fecha_creacion__date__lte=fecha_hasta)

    return render(request, 'pedidos/historial_pedidos.html', {
        'pedidos': pedidos,
        'busqueda': busqueda,
        'filtro_estado': filtro_estado,
        'fecha_desde': fecha_desde,
        'fecha_hasta': fecha_hasta,
    })
