"""
Vista de la app Reportes.
Por ahora es un placeholder (stub).
"""
from django.shortcuts import render


def reportes_ventas(request):
    """Vista placeholder para reportes de ventas."""
    return render(request, 'reportes/reportes_ventas.html')
